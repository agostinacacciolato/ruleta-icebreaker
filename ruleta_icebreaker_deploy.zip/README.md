
# Ruleta de Preguntas — Deploy rápido

Esta carpeta contiene un **index.html** listo para publicar.

## Opción A: GitHub Pages (recomendado)
1) Creá un repositorio nuevo en GitHub (p. ej. `ruleta-icebreaker`).
2) Subí **index.html** a la raíz del repo.
3) En **Settings → Pages**, elegí **Deploy from a branch** y seleccioná la rama `main` y la carpeta `/ (root)`.
4) Guardá. En segundos/minutos tendrás una URL tipo: `https://tu-usuario.github.io/ruleta-icebreaker/`.

## Opción B: Netlify (drag & drop)
1) Entrá a https://app.netlify.com/drop
2) Arrastrá el **index.html** (o la carpeta completa). Netlify te da un link público al instante.

## Opción C: Vercel
1) Creá un proyecto nuevo en https://vercel.com/import y conectá tu repo o subí el archivo.
2) Vercel te da una URL pública.

## Tip: Cambiar preguntas
- Editá el array `questions` dentro de `index.html` (está al final del archivo entre `<script>...</script>`).
- Guardá y volvé a subir/ desplegar.

¡Listo! Compartí el link con tu equipo. 🎉
